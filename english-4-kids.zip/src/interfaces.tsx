export interface CardData {
  word: string;
  translation: string;
  image: string;
  audioSrc: string;
};