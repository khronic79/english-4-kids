const PLAY = true;
const TRAIN = false;
export type AppMode = typeof PLAY | typeof TRAIN;