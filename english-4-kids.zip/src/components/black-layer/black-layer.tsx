import React from 'react';
import './black-layer.css';

function BlackLayer() {
  return (
    <div className="black-layer"></div>
  );
}

export default BlackLayer;