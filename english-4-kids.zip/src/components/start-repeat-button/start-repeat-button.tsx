import { Dispatch, SetStateAction, useContext } from 'react';
import AppModeContext from '../../context';
import { CardData } from '../../interfaces';
import { playAudio } from '../../shared/play-audio';
import './start-repeat-button.css';

interface  StartGameFunction{
  isGameStarted: number;
  startGame: Dispatch<SetStateAction<number>>;
  currentWord: boolean[];
  cardsDataMix: CardData[];
  index: number;
}

export const StartRepeatButton = ({isGameStarted, startGame, currentWord, cardsDataMix, index}: StartGameFunction): JSX.Element => {
  const { appMode } = useContext(AppModeContext);

  const startHandler = () => {
    if (isGameStarted === 0) {
      startGame(1);
      playAudio('../' + cardsDataMix[0].audioSrc);
    } else if(isGameStarted === 1) {
      playAudio('../' + cardsDataMix[index].audioSrc);
    }
  };

  const changeButtonName = () => {
    if (isGameStarted === 0) return 'start-repeat-button';
    if (isGameStarted === 1) return 'start-repeat-button game';
  };

  const thisButtonVisibility = () => {
    if (!appMode) {
      return 'button-visibility';
    }
    return '';
  }

  return (
    <div className={thisButtonVisibility()}>
      <div className={changeButtonName()} onClick={() => {startHandler()}}>
        <div className="start-button"><div>Start</div></div>
        <div className="repeat-button"></div>
      </div>
    </div>
  );
}